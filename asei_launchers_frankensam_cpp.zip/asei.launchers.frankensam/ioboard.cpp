
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations for IO board object components.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	"ioboard.h"						 // io board header
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Initialize     //////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void IOBoard::Initialize(asei::essentials::LogFile* logFile, std::string comPort)
			{
				// save reference to program log file
				this->logFile = logFile;

				serialPort.connect("\\\\.\\" + comPort, 115200); 

				// setup the output message header
				outputMessage.header.sync1 = IOBoard_Messages::SYNC1;
				outputMessage.header.sync2 = IOBoard_Messages::SYNC2;
				outputMessage.header.sync3 = IOBoard_Messages::SYNC3;
				outputMessage.header.sync4 = IOBoard_Messages::SYNC4;
				outputMessage.header.setType(IOBoard_Messages::Type::OUTPUT);
				outputMessage.header.setByteCount(sizeof(outputMessage));
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Update     //////////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void IOBoard::Update()
			{
				GetMessages();

				std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeMessage10Sent).count() >= SEND_MSG10_STRIDE_MS)
				{
					SendMessage10();
					lastTimeMessage10Sent = now;
				}

				// check if communications were lost based on timeout
				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeDataReceived).count() >= COMM_TIMEOUT_MS)
				{
					isCommunicating = false;
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     SendMessage10     ///////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void IOBoard::SendMessage10()
			{
				// calculate the checksum
				unsigned int checksum = 0;
				const unsigned char* p = reinterpret_cast<const unsigned char*>(&outputMessage);
				for (unsigned int i = 0; i < sizeof(outputMessage) - 2; i++)
					checksum += p[i];
				outputMessage.Cklsb = static_cast<char>(checksum & 0xFF);
				outputMessage.Ckmsb = static_cast<char>((checksum >> 8) & 0xFF);

				// send message and increment count
				int num = serialPort.writeBuffer(&outputMessage, sizeof(outputMessage));
				outputMessageCount++;
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     GetMessages     /////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void IOBoard::GetMessages()
			{
				int numRead = 0;
				while ((numRead = serialPort.readBuffer(&buffer[currentIndex], BUFFER_SIZE - currentIndex - 1)) > 0)
				{
					currentIndex += numRead;

					int sizeOfInputMessage = sizeof(IOBoard_Messages::IOBoardInput);

					int i = 0;
					for (i = 0; i < currentIndex - 6; i++)
					{
						// is this the start of a message? hmmmmmm
						if (buffer[i + 0] == IOBoard_Messages::SYNC1 &&
							buffer[i + 1] == IOBoard_Messages::SYNC2 &&
							buffer[i + 2] == IOBoard_Messages::SYNC3 &&
							buffer[i + 3] == IOBoard_Messages::SYNC4 &&
							buffer[i + 4] == (unsigned char)IOBoard_Messages::Type::INPUT &&
							buffer[i + 5] == sizeOfInputMessage)
						{
							// make sure we have enough data for the whole message
							if (currentIndex - i < sizeOfInputMessage)
								break;

							// verify the checksum
							unsigned int calculatedChecksum = 0;
							for (int k = i; k < i + sizeOfInputMessage - 2; k++)
								calculatedChecksum += (unsigned char)buffer[k];

							unsigned char msb = buffer[i + sizeOfInputMessage - 1];
							unsigned char lsb = buffer[i + sizeOfInputMessage - 2];

							int calcMsb = (calculatedChecksum & 0xFF00) >> 8;
							int calcLsb = (calculatedChecksum & 0x00FF);

							if (calcMsb == msb && calcLsb == lsb)
							{
								// we have a valid message so parse and update last received message
								memcpy(&inputMessage, &buffer[i], sizeOfInputMessage);
								inputMessageCount++;
								isCommunicating = true;
								lastTimeDataReceived = std::chrono::steady_clock::now();
							}

							i += sizeOfInputMessage - 1; // minus 1 since the for loop will increment
						}
					}

					int dataRemaining = currentIndex - i;
					if (dataRemaining > 0 && i != 0)
						memcpy(buffer, &buffer[i], dataRemaining);
					currentIndex = dataRemaining;
				}
			}
		}
	}
}