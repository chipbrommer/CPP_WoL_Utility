#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing the IO board and handles all messaging.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<chrono>						 // timer functions
//
#include	"asei.essentials/serialport.h"   // serial port object
#include	"asei.essentials/logfile.h"		 // log file object
//
#include	"ioboard_messages.h"			 // io board message structs
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			class IOBoard
			{
			private:
				static const int BUFFER_SIZE = 1024;		// the size of the buffer
				static const int COMM_TIMEOUT_MS = 3000;	// the timeout for communications in milliseconds
				static const int SEND_MSG10_STRIDE_MS = 20;	// the stride length for sending message 10s in milliseconds

				asei::essentials::SerialPort serialPort;	// serial port to communicate to io board
				asei::essentials::LogFile* logFile;			// reference to the program log file

				int currentIndex = 0;						// the current index into the buffer
				char buffer[BUFFER_SIZE];					// the buffer to store received data into

				std::chrono::steady_clock::time_point lastTimeMessage10Sent = std::chrono::steady_clock::now();		// time the last message 10 sent
				std::chrono::steady_clock::time_point lastTimeDataReceived = std::chrono::steady_clock::now();		// time the last data was received

				//! @brief checks for new data and parses messages from the serial connection
				void GetMessages();

				//! @brief packages up the current message 10 and sends it out over serial
				void SendMessage10();

			public:
				const std::string logPrefix = "io board: ";	// the prefix for all log entries added by the io board object

				IOBoard_Messages::IOBoardInput inputMessage = {};		// the last received message
				IOBoard_Messages::IOBoardOutput outputMessage = {};		// the last sent message

				int inputMessageCount = 0;					// the number of received messages
				int outputMessageCount = 0;					// the number of sent messages

				bool isCommunicating = false;				// boolean used by program to know if the ioboard is communicating

				//! @brief initializes the io board structure
				//! @param logFile - a reference to the program log file
				//! @param comPort - the com port the serial communications will use
				void Initialize(asei::essentials::LogFile* logFile, std::string comPort);

				//! @brief the update function that should be called in the main loop
				void Update();
			};
		}
	}
}