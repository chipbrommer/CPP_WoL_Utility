#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Message structs for IO board communications.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include    "asei.essentials/bytes.h"        // byte utility functions
//
///////////////////////////////////////////////////////////////////////////////

using namespace asei::essentials;

#pragma pack(push, 1)
namespace asei
{
    namespace launchers
    {
        namespace frankensam
        {
            class IOBoard_Messages
            {
            public:
                enum class Type
                {
                    UNKNOWN,
                    OUTPUT = 0x10,
                    INPUT = 0x20,
                    LAUNCHREQUEST = 0X1F
                };

                static const char SYNC1 = 0xA5;
                static const char SYNC2 = 0xA5;
                static const char SYNC3 = 0xF0;
                static const char SYNC4 = 0x0D;

                struct IOBoardHeader
                {
                public:
                    char sync1;
                    char sync2;
                    char sync3;
                    char sync4;

                private:
                    char msg_id;
                    char byte_count;

                public:
                    void setType(Type value)        { msg_id = (char)value; }
                    void setByteCount(int value)    { byte_count = (char)value; }

                    Type getType()                  { return (Type)msg_id; }
                    int getByteCount()              { return (int)byte_count; }
                };

                struct IOBoardOutput
                {
                    IOBoardHeader header;

                private:
                    char DiscreteOut_0_7;
                    char DiscreteOut_8_15;
                    char DiscreteOut_16_23;
                    char DiscreteOut_24_31;
                    char Mosfet_0_7;
                    char Mosfet_8_15;
                    char Mosfet_16_23;
                    char Spare_1;
                    char Spare_2;
                    char Spare_3;

                public:
                    char Cklsb;
                    char Ckmsb;
                    
                    void SetIsAcRelayEnabled(int index, bool value)         { if (index >= 0 && index < 4) DiscreteOut_0_7 = Bytes::SetBit(DiscreteOut_0_7, 0 + index, value); }
                    void SetIsDcRelayEnabled(int index, bool value)         { if (index >= 0 && index < 4) DiscreteOut_0_7 = Bytes::SetBit(DiscreteOut_0_7, 4 + index, value); }

                    void SetConsentSwitchLight(bool value)                  { DiscreteOut_24_31 = Bytes::SetBit(DiscreteOut_24_31, 5, !value); }
                    void SetArmSwitchLight(bool value)                      { DiscreteOut_24_31 = Bytes::SetBit(DiscreteOut_24_31, 6, !value); }
                    void SetFireSwitchLight(bool value)                     { DiscreteOut_24_31 = Bytes::SetBit(DiscreteOut_24_31, 7, !value); }

                    void SetIsMissile28VdcEnabled(int index, bool value)    { if (index >= 0 && index < 4) Mosfet_0_7 = Bytes::SetBit(Mosfet_0_7, 0 + index, value); }
                    void SetIsMissileArmEnabled(int index, bool value)      { if (index >= 0 && index < 4) Mosfet_0_7 = Bytes::SetBit(Mosfet_0_7, 4 + index, value); }

                    void SetIsMissileUncageEnabled(int index, bool value)   { if (index >= 0 && index < 4) Mosfet_8_15 = Bytes::SetBit(Mosfet_8_15, 0 + index, value); }
                    void SetIsMissileFireEnabled(int index, bool value)     { if (index >= 0 && index < 4) Mosfet_8_15 = Bytes::SetBit(Mosfet_8_15, 4 + index, value); }
                };

                struct IOBoardInput
                {
                    IOBoardHeader header;

                private:
                    char DiscreteOut_0_7;
                    char DiscreteOut_8_15;
                    char DiscreteOut_16_23;
                    char DiscreteOut_24_31;
                    char Mosfet_0_7;
                    char Mosfet_8_15;
                    char Mosfet_16_23;
                    char DiscreteIn_0_7;
                    char DiscreteIn_8_15;
                    char DiscreteIn_16_23;
                    char DiscreteIn_24_31;

                public:
                    char version;

                private:
                    unsigned short AD_PRI_28V_MON;
                    unsigned short AD_SEC_28V_MON;
                    unsigned short AD_SYS_28V_MON;
                    unsigned short AD_3V3_MON;
                    unsigned short AD_5V_MON;
                    unsigned short AD_12V_MON;
                    unsigned short AD_48V_MON;
                    unsigned short AD_TEMP_MON;
                    unsigned short AD_ANALOG_1_MON;
                    unsigned short AD_ANALOG_2_MON;
                    unsigned short AD_ANALOG_3_MON;
                    unsigned short AD_ANALOG_4_MON;
                    unsigned short AD_ANALOG_5_MON;
                    unsigned short AD_ANALOG_6_MON;
                    unsigned short AD_ANALOG_7_MON;
                    unsigned short AD_ANALOG_8_MON;
                    char Status_0_7;
                    char Status_8_15;
                    unsigned short Msg_Counter;
                    unsigned short Spare;
                    char Cklsb;
                    char Ckmsb;

                public:
                    bool GetIsPresent(int index)                { return index >= 0 && index < 4 ? Bytes::GetBit(DiscreteIn_0_7, 0 + index) : false; }

                    bool GetFireSwitchStatus()                  { return Bytes::GetBit(DiscreteIn_24_31, 4); }
                    bool GetBrakeEnabledStatus()                { return Bytes::GetBit(DiscreteIn_24_31, 5); }
                    bool GetConsentSwitchStatus()               { return Bytes::GetBit(DiscreteIn_24_31, 6); }
                    bool GetArmSwitchStatus()                   { return Bytes::GetBit(DiscreteIn_24_31, 7); }

                    bool GetIsAcRelayEnabled(int index)         { return index >= 0 && index < 4 ? Bytes::GetBit(DiscreteOut_0_7, 0 + index) : false; }
                    bool GetIsDcRelayEnabled(int index)         { return index >= 0 && index < 4 ? Bytes::GetBit(DiscreteOut_0_7, 4 + index) : false; }

                    bool GetIsMissile28VdcEnabled(int index)    { return index >= 0 && index < 4 ? Bytes::GetBit(Mosfet_0_7, 0 + index) : false; }
                    bool GetIsMissileArmEnabled(int index)      { return index >= 0 && index < 4 ? Bytes::GetBit(Mosfet_0_7, 4 + index) : false; }

                    bool GetIsMissileUncageEnabled(int index)   { return index >= 0 && index < 4 ? Bytes::GetBit(Mosfet_8_15, 0 + index) : false; }
                    bool GetIsMissileFireEnabled(int index)     { return index >= 0 && index < 4 ? Bytes::GetBit(Mosfet_8_15, 4 + index) : false; }

                    int GetMissileAudioSelectedIndex() 
                    { 
                        switch (DiscreteIn_8_15 & (0b111))
                        {
                        case 0b100: return 1; break;
                        case 0b010: return 2; break;
                        case 0b001: return 3; break;
                        }

                        return 0;
                    }
                };
            };
        }
    }
}
#pragma pack(pop)