
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations for launcher object components.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<iostream>						 // cout function
//
#include	"launcher.h"					 // launcher header
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Launcher     ////////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			Launcher::Launcher() :
				settingsFile("C:\\Settings\\frankensam_settings.json"),
				logFile("C:\\Logs\\frankensam_log.txt", true)
			{
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Initialize     //////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			bool Launcher::Initialize()
			{
				if (!settingsFile.Load())
				{
					std::cout << "failed to load settings\n";
					return false;
				}

				ioBoard.Initialize(&logFile, settingsFile.data.ioBoardComPort);
				safetyBoard.Initialize(&logFile, settingsFile.data.safetyBoardComPort);
				powerBoard.Initialize(&logFile, settingsFile.data.powerBoardComPort);
				missionComputer.Initialize(VERSIONMAJOR, VERSIONMINOR, VERSIONBUILD,
					settingsFile.data.broadcastIP, settingsFile.data.broadcastPort, settingsFile.data.listenPort);
				for (int i = 0; i < NUM_MISSILES; i++)
					missiles[i].Initialize(i, &ioBoard, &safetyBoard);

				return true;
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Start     ///////////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			bool Launcher::Start()
			{
				logFile.AddLine("launcher: FrankenSAM v" + std::to_string(VERSIONMAJOR) + "." + std::to_string(VERSIONMINOR) + "." + std::to_string(VERSIONBUILD));

				// wait for ioboard, safetyboard, and powerboard to start talking
				std::chrono::steady_clock::time_point startTimeWaitingForBoardComms = std::chrono::steady_clock::now();
				while (false)
				{
					ioBoard.Update();
					safetyBoard.Update();
					powerBoard.Update();

					if (ioBoard.isCommunicating && safetyBoard.isCommunicating && powerBoard.isCommunicating)
					{
						logFile.AddLine(ioBoard.logPrefix + "version " + std::to_string((int)ioBoard.inputMessage.version));
						logFile.AddLine(powerBoard.logPrefix + "version " + std::to_string((int)powerBoard.statusMessage.version));
						break;
					}

					std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
					if (std::chrono::duration_cast<std::chrono::milliseconds>(now - startTimeWaitingForBoardComms).count() > 500)
					{
						if (!ioBoard.isCommunicating)		logFile.AddLine(ioBoard.logPrefix + "failed to communicate in time");
						if (!safetyBoard.isCommunicating)	logFile.AddLine(safetyBoard.logPrefix + "failed to communicate in time");
						if (!powerBoard.isCommunicating)	logFile.AddLine(powerBoard.logPrefix + "failed to communicate in time");

						// since atleast one of the boards didn't talk in time
						// stop the program
						return false;
					}

					// slow things down a little
					std::this_thread::sleep_for(std::chrono::milliseconds(1));
				}

				isRunning = true;
				running_thread = std::move(std::thread([this]() {
					// main loop
					while (isRunning)
					{
						std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();

						if (!isCheckInventoryComplete)
							PerformInventoryCheckLogic();

						// update all objects
						ioBoard.Update();
						safetyBoard.Update();
						powerBoard.Update();
						missionComputer.Update(selectedMissileIndex, missiles);
						for (Missile missile : missiles)
							missile.Update();

						PerformLogicForSwitches();
						PerformLoopStats(now);

						// slow things down a little
						std::this_thread::sleep_for(std::chrono::milliseconds(1));
					}
				}));

				return true;
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     PerformInventoryCheckLogic     //////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void Launcher::PerformInventoryCheckLogic()
			{
				std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();

				if (!hasSetMissilePower)
				{
					ioBoard.outputMessage.SetIsAcRelayEnabled(checkInventoryMissileIndex, true);
					ioBoard.outputMessage.SetIsMissile28VdcEnabled(checkInventoryMissileIndex, true);
					timeMissilePoweredOn = std::chrono::steady_clock::now();
					hasSetMissilePower = true;
					std::cout << "enabling power for missile " << (checkInventoryMissileIndex + 1) << "\n";
				}
				else if (std::chrono::duration_cast<std::chrono::milliseconds>(now - timeMissilePoweredOn).count() >= 300)
				{
					ioBoard.outputMessage.SetIsAcRelayEnabled(checkInventoryMissileIndex, false);
					ioBoard.outputMessage.SetIsMissile28VdcEnabled(checkInventoryMissileIndex, false);
					hasSetMissilePower = false;
					checkInventoryMissileIndex++;
					if (checkInventoryMissileIndex >= 4)
					{
						// set the first selected missile index
						for (int i = 0; i < NUM_MISSILES; i++)
						{
							if (missiles[i].isPresent)
							{
								selectedMissileIndex = i;
								break;
							}
						}

						isCheckInventoryComplete = true;
						std::cout << "inventory check complete\n";
					}
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     PerformLogicForSwitches     /////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void Launcher::PerformLogicForSwitches()
			{
				bool canFireAccordingToBrake = false;

				bool brakeEnabled = ioBoard.inputMessage.GetBrakeEnabledStatus();
				if (isBrakeEnabled != brakeEnabled)
				{
					isBrakeEnabled = brakeEnabled;
					if (isBrakeEnabled)
						brakeToggleTime = std::chrono::steady_clock::now();
				}

				// see if the brake has been enabled for atleast 5 seconds (if so then can fire)
				std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
				if (isBrakeEnabled && std::chrono::duration_cast<std::chrono::milliseconds>(now - brakeToggleTime).count() > 5000)
				{
					canFireAccordingToBrake = true;
				}

				// get switch statuses
				bool armEnabled = ioBoard.inputMessage.GetArmSwitchStatus();
				if (isArmSwitchEnabled != armEnabled)
				{
					isArmSwitchEnabled = armEnabled;
					ioBoard.outputMessage.SetArmSwitchLight(isArmSwitchEnabled);
				}

				bool consentEnabled = ioBoard.inputMessage.GetConsentSwitchStatus();
				if (isConsentSwitchEnabled != consentEnabled)
				{
					isConsentSwitchEnabled = consentEnabled;
					ioBoard.outputMessage.SetConsentSwitchLight(isConsentSwitchEnabled);
				}

				bool fireEnabled = ioBoard.inputMessage.GetFireSwitchStatus();
				if (isFireSwitchEnabled != fireEnabled)
				{
					isFireSwitchEnabled = fireEnabled;
					ioBoard.outputMessage.SetFireSwitchLight(isFireSwitchEnabled);

					// capture fire toggle
					if (canFireAccordingToBrake && isArmSwitchEnabled && isConsentSwitchEnabled && isFireSwitchEnabled && selectedMissileIndex >= 0)
						missiles[selectedMissileIndex].BeginFire();
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     PerformLoopStats     ////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void Launcher::PerformLoopStats(std::chrono::steady_clock::time_point start)
			{
				timesExecuted++;

				// keep track of time statistics to gauge how the execution time for the loop is doing
				std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
				totalTime += std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();
				if (std::chrono::duration_cast<std::chrono::milliseconds>(end - lastTime).count() >= 1000)
				{
					std::cout << "stats >> avg execution time: " << ((totalTime / (double)timesExecuted) / 1000000.0) << "ms, execs per sec: " << timesExecuted << "\n";

					totalTime = 0;
					timesExecuted = 0;

					lastTime = end;
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     ~Launcher     ///////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			Launcher::~Launcher()
			{
				isRunning = false;
				std::cout << "launcher: waiting for thread to stop running\n";
				if (running_thread.joinable())
					running_thread.join();
			}
		}
	}
}