#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing the whole launcher. Manages all the sub
//					objects and most of the main logic.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<thread>						 // thread object
//
#include	"asei.essentials/settingsfile.h" // settings file object
#include	"asei.essentials/logfile.h"		 // log file object
//
#include	"ioboard.h"						 // io board object
#include	"safetyboard.h"					 // safety board object
#include	"powerboard.h"					 // power board object
#include	"settings.h"					 // settings data structure
#include	"missile.h"						 // missile object
#include	"missioncomputer.h"				 // mission computer object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			class Launcher
			{
			public:
				const unsigned char VERSIONMAJOR = 0;	// the major component of the version
				const unsigned char VERSIONMINOR = 1;	// the minor component of the version
				const unsigned char VERSIONBUILD = 0;	// the build component of the version

			private:
				bool isRunning = false;					// boolean to control the background thread (set to false to stop thread)
				std::thread running_thread;				// the background thread that runs all main launcher logic

				long long totalTime = 0;				// used by the loop timing test
				int timesExecuted = 0;					// used by the loop timing test
				std::chrono::steady_clock::time_point lastTime = std::chrono::steady_clock::now();

				bool isCheckInventoryComplete = false;	// used by the missile inventory check
				int checkInventoryMissileIndex = 0;		// used by the missile inventory check
				bool hasSetMissilePower = false;		// used by the missile inventory check
				std::chrono::steady_clock::time_point timeMissilePoweredOn = std::chrono::steady_clock::now();

				std::chrono::steady_clock::time_point brakeToggleTime = std::chrono::steady_clock::now();

				//! @brief does inventory check
				void PerformInventoryCheckLogic();

				//! @brief handles switch lights and capturing fire event
				void PerformLogicForSwitches();

				//! @brief calculates stats on loop execution
				//! @param start - the start time of the loop execution
				void PerformLoopStats(std::chrono::steady_clock::time_point start);
				 
			public:
				bool isBrakeEnabled = false;			// the current weight on wheels switch state
				bool isConsentSwitchEnabled = false;	// the current consent switch state
				bool isArmSwitchEnabled = false;		// the current arm switch state
				bool isFireSwitchEnabled = false;		// the current fire switch state

				asei::essentials::SettingsFile<SettingsData> settingsFile;	// the launcher's settings file
				asei::essentials::LogFile logFile;							// the launcher's main log file

				IOBoard ioBoard;						// the io board object
				SafetyBoard safetyBoard;				// the safety board object
				PowerBoard powerBoard;					// the power board object
				MissionComputer missionComputer;		// the mission computer object

				static const int NUM_MISSILES = 4;		// the number of missiles support
				Missile missiles[NUM_MISSILES];			// the collection of missile objects

				unsigned char selectedMissileIndex = -1; // the index of the currently selected missile for launch

				//! @brief constructor for the launcher object
				Launcher();

				//! @brief deconstructor for the launcher object.
				//!        used to clean up things like background thread
				~Launcher();

				//! @brief initializes launcher object
				bool Initialize();

				//! @brief does some initial startup processes then starts
				//!        the background thread for main launcher logic
				bool Start();
			};
		}
	}
}