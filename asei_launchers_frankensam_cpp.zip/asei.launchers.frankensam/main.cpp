﻿
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	The main entry point into the program.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	"launcher.h"					 // launcher object
#include	"webserver.h"					 // web server object
//
///////////////////////////////////////////////////////////////////////////////

using namespace asei::launchers::frankensam;

Launcher launcher;
WebServer webServer("C:\\wwwroot\\", 8000, &launcher);    

int main()
{
	launcher.Initialize();

	// this runs a background thread
	if (!launcher.Start())
		return -1;

	webServer.Start();	// this will block
	 
	return 0;
} 