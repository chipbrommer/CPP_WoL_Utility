
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations for missile object components.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include    "missile.h"                      // missile header
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
    namespace launchers
    {
        namespace frankensam
        {
            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     Initialize     //////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void Missile::Initialize(int index, IOBoard* ioboard, SafetyBoard* safetyboard)
            {
                this->index = index;
                this->ioboard = ioboard;
                this->safetyboard = safetyboard;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     Update     //////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void Missile::Update()
            {
                std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();

                if (state == State::NOT_DETECTED)
                {
                    isPresent = ioboard->inputMessage.GetIsPresent(index);
                    if (isPresent)
                        state = State::WAITING_FOR_ENGAGEMENT;
                }

                else if (state == State::WAITING_FOR_ENGAGEMENT)
                    ; // no logic here (waiting for "BeginEngagement" method to be called)

                else if (state == State::ENGAGING)
                {
                    ioboard->outputMessage.SetIsMissileUncageEnabled(index, true);
                }

                else if (state == State::READY_FOR_FIRE)
                    ; // no logic here (waiting for "BeginFire" method to be called)

                else if (state == State::FIRING)
                {
                    if (fireState == FireState::ARM)
                    {
                        ioboard->outputMessage.SetIsMissileArmEnabled(index, true);
                        timeSinceLastAction = std::chrono::steady_clock::now();
                        fireState == FireState::FIRE;
                    }
                    else if (fireState == FireState::FIRE && std::chrono::duration_cast<std::chrono::milliseconds>(now - timeSinceLastAction).count() > 50)
                    {
                        ioboard->outputMessage.SetIsMissileFireEnabled(index, true);
                        timeSinceLastAction = std::chrono::steady_clock::now();
                        fireState == FireState::CHECK_AWAY;
                    }
                    else if (fireState == FireState::CHECK_AWAY && std::chrono::duration_cast<std::chrono::milliseconds>(now - timeSinceLastAction).count() > 50)
                    {
                        isPresent = ioboard->inputMessage.GetIsPresent(index);
                        if (!isPresent)
                        {
                            // reset signals
                            ioboard->outputMessage.SetIsMissileUncageEnabled(index, false);
                            ioboard->outputMessage.SetIsMissileArmEnabled(index, false);
                            ioboard->outputMessage.SetIsMissileFireEnabled(index, false);
                            fireState == FireState::DONE;
                        }
                    }
                }
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     BeginEngagement     /////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void Missile::BeginEngagement()
            {
                // make sure we are waiting for an engagement
                if (state != State::WAITING_FOR_ENGAGEMENT)
                    return;

                state == State::ENGAGING;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     BeginFire     ///////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void Missile::BeginFire()
            {
                // make sure we are waiting for fire
                if (state != State::READY_FOR_FIRE)
                    return;

                state = State::FIRING;
            }
        }
    }
}