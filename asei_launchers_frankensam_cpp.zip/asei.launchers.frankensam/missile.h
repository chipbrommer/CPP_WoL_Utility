#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing a missile and handles logic related
//                  to the missile.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include    <chrono>                         // timer functions
//
#include    "safetyboard.h"                  // safety board object
#include    "ioboard.h"                      // io board object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
    namespace launchers
    {
        namespace frankensam
        {
            class Missile
            {
            private:
                enum class State
                {
                    NOT_DETECTED,
                    WAITING_FOR_ENGAGEMENT,
                    ENGAGING,
                    READY_FOR_FIRE,
                    FIRING
                };

                enum class FireState
                {
                    ARM,
                    FIRE,
                    CHECK_AWAY,
                    DONE
                };

                int index;                              // the 0-based index of the missile
                IOBoard* ioboard;                       // the reference to the launcher io board
                SafetyBoard* safetyboard;               // the reference to the launcher safety board

                std::chrono::steady_clock::time_point timeSinceLastAction = std::chrono::steady_clock::now();

            public:
                bool isPresent = false;                 // indicator if the missile is present (this gets updated during inventory check)
                bool is28VEnabled = false;              // indicator if 28v to lau is enabled
                bool is115VEnabled = false;             // indicator if 115v to lau is enabled
                bool isPowerEnabled = false;            // indicator if power to missile is enabled

                State state = State::NOT_DETECTED;      // the current state of the missile
                FireState fireState = FireState::ARM;       // the current fire state

                //! @brief initializes the missile object
                //! @param index - the 0-based index of the missile
                //! @param ioboard - the reference to the launcher io board
                //! @param safetyboard - the reference to the launcher safety board
                void Initialize(int index, IOBoard* ioboard, SafetyBoard* safetyboard);

                //! @brief the update function that should be called in the main loop
                void Update();

                //! @brief starts the engagement
                void BeginEngagement();

                //! @brief start the fire sequence
                void BeginFire();
            };
        }
    }
}