
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations for mission computer object components.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	"missioncomputer.h"				 // mission computer header
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     ~MissionComputer     ////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			MissionComputer::~MissionComputer()
			{
				if (udpClient != nullptr)
					delete udpClient;
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Initialize     //////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void MissionComputer::Initialize(unsigned char versionMajor, unsigned char versionMinor, unsigned char versionBuild,
				std::string broadcastIP, unsigned short broadcastPort, unsigned short listenPort)
			{
				broadcastEndPoint.ip = broadcastIP;
				broadcastEndPoint.port = broadcastPort;

				// setup the heartbeat message
				heartbeatMessage.header.sync1 = MissionComputer_Messages::SYNC1;
				heartbeatMessage.header.sync2 = MissionComputer_Messages::SYNC2;
				heartbeatMessage.header.sync3 = MissionComputer_Messages::SYNC3;
				heartbeatMessage.header.sync4 = MissionComputer_Messages::SYNC4;
				heartbeatMessage.header.SetMessageType(MissionComputer_Messages::Type::HEARTBEAT);
				heartbeatMessage.header.length = sizeof(heartbeatMessage);

				// setup the status message
				statusMessage.header.sync1 = MissionComputer_Messages::SYNC1;
				statusMessage.header.sync2 = MissionComputer_Messages::SYNC2;
				statusMessage.header.sync3 = MissionComputer_Messages::SYNC3;
				statusMessage.header.sync4 = MissionComputer_Messages::SYNC4;
				statusMessage.header.SetMessageType(MissionComputer_Messages::Type::STATUS);
				statusMessage.header.length = sizeof(statusMessage);
				statusMessage.versionMajor = versionMajor;
				statusMessage.versionMinor = versionMinor;
				statusMessage.versionBuild = versionBuild;

				udpClient = new essentials::UdpClient(listenPort);
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Update     //////////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void MissionComputer::Update(uint8_t selectedMissileIndex, Missile missiles[4])
			{
				ReceiveData();

				std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeAt1Hz).count() >= 1000)
				{
					// update heartbeat message
					heartbeatMessage.number++;

					BroadcastHeartbeat();
					lastTimeAt1Hz = now;
				}

				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeAt5Hz).count() >= 200)
				{
					// update status message
					statusMessage.selectedMissileIndex = selectedMissileIndex;
					statusMessage.SetIsArmEnabled(true);
					for (int i = 0; i < 4; i++)
					{
						statusMessage.missiles[i].SetIsPresent(missiles[i].isPresent);
						statusMessage.missiles[i].SetIs28VEnabled(missiles[i].is28VEnabled);
						statusMessage.missiles[i].SetIs115VEnabled(missiles[i].is115VEnabled);
						statusMessage.missiles[i].SetIsPowerEnabled(missiles[i].isPowerEnabled);

						statusMessage.missiles[i].SetCurrent28V(0);
						statusMessage.missiles[i].SetVoltage28V(0);
						statusMessage.missiles[i].SetCurrent115V(0);
						statusMessage.missiles[i].SetVoltage115V(0);
					}

					SendStatusMessage();
					lastTimeAt5Hz = now;
				}

				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeDataReceived).count() > 3000)
				{
					isCommunicating = false;
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     ReceiveData     /////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void MissionComputer::ReceiveData()
			{
				essentials::UdpClient::IPEndPoint endPoint;
				int numReceived = udpClient->Recv(buffer, 1024, &endPoint);

				if (numReceived < sizeof(header))
					return;

				memcpy(&header, buffer, sizeof(header));

				switch (header.GetMessageType())
				{
				case MissionComputer_Messages::Type::HEARTBEAT:
					if (numReceived < sizeof(heartbeatMessage))
						return;

					unsigned short checksum = 0;
					for (unsigned int i = 0; i < sizeof(heartbeatMessage) - 2; i++)
						checksum += (unsigned char)buffer[i];

					unsigned short receivedChecksum = 0;
					memcpy(&receivedChecksum, &buffer[sizeof(heartbeatMessage) - 2], sizeof(receivedChecksum));

					if (receivedChecksum != checksum)
						return;

					memcpy(&heartbeatMessage, buffer, sizeof(heartbeatMessage));
					clientEndPoint.ip = endPoint.ip;
					clientEndPoint.port = endPoint.port;
					hasClientEndpoint = true;
					isCommunicating = true;
					lastTimeDataReceived = std::chrono::steady_clock::now();
					break;
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     BroadcastHeartbeat     //////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void MissionComputer::BroadcastHeartbeat()
			{
				int calculatedChecksum = 0;
				unsigned char* data = reinterpret_cast<unsigned char*>(&heartbeatMessage);
				for (int i = 0; i < sizeof(heartbeatMessage) - 2; i++)
					calculatedChecksum += (unsigned char)data[i];
				heartbeatMessage.checksum = calculatedChecksum;

				udpClient->Send(&heartbeatMessage, heartbeatMessage.header.length, broadcastEndPoint);
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     SendStatusMessage     ///////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void MissionComputer::SendStatusMessage()
			{
				if (!hasClientEndpoint)
					return;

				int calculatedChecksum = 0;
				unsigned char* data = reinterpret_cast<unsigned char*>(&statusMessage);
				for (int i = 0; i < sizeof(statusMessage) - 2; i++)
					calculatedChecksum += (unsigned char)data[i];
				statusMessage.checksum = calculatedChecksum;

				udpClient->Send(&statusMessage, statusMessage.header.length, clientEndPoint);
			}
		}
	}
}