#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing the mission computer and handles logic
//					and communications.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<chrono>						 // timer functions
//
#include	"asei.essentials/udpclient.h"	 // udp client object
//
#include	"missioncomputer_messages.h"	 // mission computer messages
#include	"missile.h"						 // missile object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			class MissionComputer
			{
			private:
				essentials::UdpClient* udpClient = nullptr;					// the current udp client used to send and received data over
				bool hasClientEndpoint = false;								// indicator used to know if we have received a client endpoint
				essentials::UdpClient::IPEndPoint clientEndPoint;			// the last received client endpoint

				MissionComputer_Messages::Header header{};					// the last received message header
				MissionComputer_Messages::Heartbeat heartbeatMessage{};		// the last received heartbeat message
				MissionComputer_Messages::Status statusMessage{};			// the last sent status message

				essentials::UdpClient::IPEndPoint broadcastEndPoint;		// the endpoint to broadcast the discovery message to
				char buffer[1024] = { 0 };									// a buffer to store received data for processing

				std::chrono::steady_clock::time_point lastTimeAt1Hz = std::chrono::steady_clock::now();			// a timepoint used to determine when to do the next 1 Hz thing
				std::chrono::steady_clock::time_point lastTimeAt5Hz = std::chrono::steady_clock::now();			// a timepoint used to determine when to do the next 5 Hz thing
				std::chrono::steady_clock::time_point lastTimeDataReceived = std::chrono::steady_clock::now();	// a timepoint used to keep track of the last received message

				//! @brief receives any available data from the udp listener
				void ReceiveData();

				//! @brief sends out the discovery message (the heartbeat message) out over UDP broadcast
				void BroadcastHeartbeat();

				//! @brief sends the current status of all things to the last endpoint data was received from
				void SendStatusMessage();

			public:
				//! @brief deconstructor for mission computer object used to clean things up.
				~MissionComputer();

				bool isCommunicating = false;		// indicator showing if the mission computer is communicating

				//! @brief initializes the mission computer object
				//! @param versionMajor - the major component of the version 
				//! @param versionMinor - the minor component of the version
				//! @param versionBuild - the build component of the version
				//! @param broadcastIP - the ip the discovery broadcast message will be sent out over
				//! @param broadcastPort - the port the discovery broadcast message will be sent out over
				//! @param listenPort - the port that received data will get recevied on
				void Initialize(unsigned char versionMajor, unsigned char versionMinor, unsigned char versionBuild,
					std::string broadcastIP, unsigned short broadcastPort, unsigned short listenPort);

				//! @brief the update function that should be called in the main loop
				//! @param selectedMissileIndex - the 0-based index of the missile currently selected for launch
				//! @param missiles - the missiles
				void Update(uint8_t selectedMissileIndex, Missile missiles[4]);
			};
		}
	}
}