#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Message structs for mission computer communications.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
//
///////////////////////////////////////////////////////////////////////////////

#pragma pack(push, 1)
namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			class MissionComputer_Messages
			{
            public:
                static const uint8_t SYNC1 = 0xEB;
                static const uint8_t SYNC2 = 0xDC;
                static const uint8_t SYNC3 = 0xCD;
                static const uint8_t SYNC4 = 0xBE;

                enum class Type
                {
                    UNKNOWN = 0,
                    HEARTBEAT = 440,
                    STATUS = 441
                };

                struct Header
                {
                public:     uint8_t sync1;
                public:     uint8_t sync2;
                public:     uint8_t sync3;
                public:     uint8_t sync4;
                private:    uint16_t messageType;
                public:     uint16_t length;

                public:
                    Type GetMessageType() { return (Type)messageType; }
                    void SetMessageType(Type value) { messageType = (uint16_t)value; }
                };

                struct Heartbeat
                {
                public: Header header;
                public: uint32_t number;
                public: uint16_t checksum;
                };

                struct Status
                {
                public:
                    struct Missile
                    {
                    public:     uint8_t index;
                    private:    uint16_t values;
                    private:    uint16_t current28v;
                    private:    uint16_t voltage28v;
                    private:    uint16_t current115v;
                    private:    uint16_t voltage115v;

                    public:
                        void SetIsPresent(bool value)           { values = (values & ~(1 << 0)) | ((value ? 1 : 0) << 0); }
                        void SetIs28VEnabled(bool value)        { values = (values & ~(1 << 1)) | ((value ? 1 : 0) << 1); }
                        void SetIs115VEnabled(bool value)       { values = (values & ~(1 << 2)) | ((value ? 1 : 0) << 2); }
                        void SetIsPowerEnabled(bool value)      { values = (values & ~(1 << 3)) | ((value ? 1 : 0) << 3); }

                        void SetCurrent28V(float value)         { current28v = (uint16_t)(value * 100.0); }
                        void SetVoltage28V(float value)         { voltage28v = (uint16_t)(value * 100.0); }
                        void SetCurrent115V(float value)        { current115v = (uint16_t)(value * 100.0); }
                        void SetVoltage115V(float value)        { voltage115v = (uint16_t)(value * 100.0); }
                    };

                public:     Header header;
                private:    uint16_t values;
                public:     uint8_t selectedMissileIndex;
                public:     uint8_t versionMajor;
                public:     uint8_t versionMinor;
                public:     uint8_t versionBuild;
                public:     Missile missiles[4];
                public:     uint16_t checksum;

                public:
                    void SetIsConsentEnabled(bool value)      { values = (values & ~(1 << 0)) | ((value ? 1 : 0) << 0); }
                    void SetIsArmEnabled(bool value)          { values = (values & ~(1 << 1)) | ((value ? 1 : 0) << 1); }
                    void SetIsFireEnabled(bool value)         { values = (values & ~(1 << 2)) | ((value ? 1 : 0) << 2); }
                    void SetIsPlatformInterlock(bool value)   { values = (values & ~(1 << 3)) | ((value ? 1 : 0) << 3); }
                };
			};
		}
	}
}
#pragma pack(pop)