
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations for power board object components.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
#include	"powerboard.h"					 // power board header
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Initialize     //////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void PowerBoard::Initialize(asei::essentials::LogFile* logFile, std::string comPort)
			{
				this->logFile = logFile;

				serialPort.connect("\\\\.\\" + comPort, 115200);

				requestMessage.header.sync1 = PowerBoard_Messages::SYNC1;
				requestMessage.header.sync2 = PowerBoard_Messages::SYNC2;
				requestMessage.header.sync3 = PowerBoard_Messages::SYNC3;
				requestMessage.header.sync4 = PowerBoard_Messages::SYNC4;
				requestMessage.header.SetType(PowerBoard_Messages::Type::REQUEST);
				requestMessage.header.length = sizeof(requestMessage);
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Update     //////////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void PowerBoard::Update()
			{
				GetMessages();

				std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastMessageSent).count() > REQUEST_MSG_STRIDE_MS)
				{
					SendRequestMessage();
					lastMessageSent = now;
				}

				// check if communications were lost based on timeout
				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeDataReceived).count() >= COMM_TIMEOUT_MS)
				{
					isCommunicating = false;
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     SentOutputMessage     ///////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void PowerBoard::SendRequestMessage()
			{
				unsigned int checksum = 0;
				const unsigned char* p = reinterpret_cast<const unsigned char*>(&requestMessage);
				for (unsigned int i = 0; i < sizeof(requestMessage) - 2; i++)
					checksum += p[i];
				requestMessage.cklsb = static_cast<char>(checksum & 0xFF);
				requestMessage.ckmsb = static_cast<char>((checksum >> 8) & 0xFF);

				// send message and increment count
				int num = serialPort.writeBuffer(&requestMessage, sizeof(requestMessage));
				requestMessageCount++;
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     GetMessages     /////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void PowerBoard::GetMessages()
			{
				int numRead = 0;
				while ((numRead = serialPort.readBuffer(&buffer[currentIndex], BUFFER_SIZE - currentIndex - 1)) > 0)
				{
					currentIndex += numRead;

					int sizeOfInputMessage = sizeof(PowerBoard_Messages::Status);

					int i = 0;
					for (i = 0; i < currentIndex - 6; i++)
					{
						// is this the start of a message? hmmmmmm
						if (buffer[i + 0] == PowerBoard_Messages::SYNC1 &&
							buffer[i + 1] == PowerBoard_Messages::SYNC2 &&
							buffer[i + 2] == PowerBoard_Messages::SYNC3 &&
							buffer[i + 3] == PowerBoard_Messages::SYNC4 &&
							buffer[i + 4] == (unsigned char)PowerBoard_Messages::Type::STATUS &&
							buffer[i + 5] == sizeOfInputMessage)
						{
							// make sure we have enough data for the whole message
							if (currentIndex - i < sizeOfInputMessage)
								break;

							// verify the checksum
							unsigned int calculatedChecksum = 0;
							for (int k = i; k < i + sizeOfInputMessage - 2; k++)
								calculatedChecksum += (unsigned char)buffer[k];

							unsigned char msb = buffer[i + sizeOfInputMessage - 1];
							unsigned char lsb = buffer[i + sizeOfInputMessage - 2];

							int calcMsb = (calculatedChecksum & 0xFF00) >> 8;
							int calcLsb = (calculatedChecksum & 0x00FF);

							if (calcMsb == msb && calcLsb == lsb)
							{
								memcpy(&statusMessage, &buffer[i], sizeOfInputMessage);
								statusMessageCount++;
								isCommunicating = true;
								lastTimeDataReceived = std::chrono::steady_clock::now();
							}

							i += sizeOfInputMessage - 1; // minus 1 since the for loop will increment
						}
					}

					int dataRemaining = currentIndex - i;
					if (dataRemaining > 0 && i != 0)
						memcpy(buffer, &buffer[i], dataRemaining);
					currentIndex = dataRemaining;
				}
			}
		}
	}
}