#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing the power board and handles logic
//					and communications.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
#include	<string>						 // string type
#include	<chrono>						 // timer functions
//               
#include	"asei.essentials/logfile.h"		 // log file object
#include	"asei.essentials/serialport.h"	 // serial port object
//               
#include	"powerboard_messages.h"			 // power board messages
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			class PowerBoard
			{
			private:
				static const int BUFFER_SIZE = 1024;			// the max size of the buffer to store data in
				static const int COMM_TIMEOUT_MS = 3000;		// the timeout for communications in milliseconds
				static const int REQUEST_MSG_STRIDE_MS = 20;	// the stride length for sending request messages in milliseconds

				essentials::LogFile* logFile;					// reference to the launcher's main log file
				essentials::SerialPort serialPort;				// the serial port used to communicate with the power board

				int currentIndex = 0;							// the current index into the buffer
				char buffer[BUFFER_SIZE];						// the buffer to store received data into

				std::chrono::steady_clock::time_point lastMessageSent = std::chrono::steady_clock::now();			// time the last message was sent
				std::chrono::steady_clock::time_point lastTimeDataReceived = std::chrono::steady_clock::now();		// time the last data was received

				//! @brief receives any data and tries to parse messages
				void GetMessages();

				//! @brief sends the request message
				void SendRequestMessage();

			public:
				const std::string logPrefix = "power board: ";		// the prefix for all log entries added by the power board object

				PowerBoard_Messages::Request requestMessage = {};	// the last sent request message
				PowerBoard_Messages::Status statusMessage = {};		// the last received status message

				int requestMessageCount = 0;						// the number of request messages sent
				int statusMessageCount = 0;							// the number of status messages received

				bool isCommunicating = false;						// indicator used to know if the power board is communicating

				//! @brief initializes the power board object
				//! @param logFile - reference to the launcher's main log file
				//! @param comPort - the port that the serial communications will use
				void Initialize(asei::essentials::LogFile* logFile, std::string comPort);

				//! @brief the update function that should be called in the main loop
				void Update();
			};
		}
	}
}