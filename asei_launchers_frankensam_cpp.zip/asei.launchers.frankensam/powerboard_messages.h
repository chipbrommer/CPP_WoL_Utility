#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Message structs for power board communications
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
//
///////////////////////////////////////////////////////////////////////////////

#pragma pack(push, 1)
namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			class PowerBoard_Messages
			{
			public:
				enum class Type
				{
					UNKNOWN,
					REQUEST	= 0x10,
					STATUS	= 0x20
				};

				static const char SYNC1 = 0xA5;
				static const char SYNC2 = 0xA5;
				static const char SYNC3 = 0xF0;
				static const char SYNC4 = 0x0D;

				struct Header
				{
				public:
					uint8_t sync1;   // 0  0xA5
					uint8_t sync2;   // 1  0xA5
					uint8_t sync3;   // 2  0xF0
					uint8_t sync4;   // 3  0x0D
				private: 
					uint8_t type;
				public: 
					uint8_t length;

					Type GetType() { return (Type)type; }
					void SetType(Type value) { type = (uint8_t)value; }
				};

				struct Request
				{
				public:
					Header header;
					uint8_t responseRequested;
					uint8_t cklsb;
					uint8_t ckmsb;
				};

				struct Status
				{
				public:
					struct Power
					{
					public:
						uint16_t dcVoltage;
						uint16_t dcCurrent;
						uint16_t acVoltagePhase1;
						uint16_t acCurrentPhase1;
						uint16_t acVoltagePhase2;
						uint16_t acCurrentPhase2;
						uint16_t acVoltagePhase3;
						uint16_t acCurrentPhase3;
					};

					Header header;
					Power inputPower;
					Power lauPower[4];
					uint8_t version;
					uint8_t cklsb;
					uint8_t ckmsb;
				};
			};
		}
	}
}
#pragma pack(pop)