
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations for safety board object components.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
#include    "safetyboard.h"                  // safety board header
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     Initialize     //////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void SafetyBoard::Initialize(asei::essentials::LogFile* logFile, std::string comPort)
            {
                this->logFile = logFile;

                serialPort.connect("\\\\.\\" + comPort, 9600);

                lastSentHeartbeatMessage.header.sync1 = SafetyBoard_Messages::SYNC1;
                lastSentHeartbeatMessage.header.sync2 = SafetyBoard_Messages::SYNC2;
                lastSentHeartbeatMessage.header.sync3 = SafetyBoard_Messages::SYNC3;
                lastSentHeartbeatMessage.header.sync4 = SafetyBoard_Messages::SYNC4;
                lastSentHeartbeatMessage.header.setType(SafetyBoard_Messages::Type::HEARTBEAT_MESSAGE);
                lastSentHeartbeatMessage.tag1 = SafetyBoard_Messages::TAG_BIT_1;
                lastSentHeartbeatMessage.tag2 = SafetyBoard_Messages::TAG_BIT_2;
                lastSentHeartbeatMessage.tag3 = SafetyBoard_Messages::TAG_BIT_3;
                lastSentHeartbeatMessage.eom = SafetyBoard_Messages::EOM_BIT;

                lastSentCircuitEnableMessage.sync1 = SafetyBoard_Messages::SYNC1;
                lastSentCircuitEnableMessage.sync2 = SafetyBoard_Messages::SYNC2;
                lastSentCircuitEnableMessage.sync3 = SafetyBoard_Messages::SYNC3;
                lastSentCircuitEnableMessage.sync4 = SafetyBoard_Messages::SYNC4;
                lastSentCircuitEnableMessage.tag1 = SafetyBoard_Messages::TAG_BIT_1;
                lastSentCircuitEnableMessage.tag2 = SafetyBoard_Messages::TAG_BIT_2;
                lastSentCircuitEnableMessage.tag3 = SafetyBoard_Messages::TAG_BIT_3;
                lastSentCircuitEnableMessage.eom = SafetyBoard_Messages::EOM_BIT;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     Update     //////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
			void SafetyBoard::Update()
			{
                GetMessages();

				std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();

                // send the heartbeat message at a rate of 1 hz
				if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeHeartbeatMessageSent).count() >= (1000 / HEARTBEAT_RATE_HZ))
				{
					QueueHeartbeat();
                    QueueCircuitEnable(SafetyBoard_Messages::CircuitEnable::CircuitEnum::CIRCUIT1);
					lastTimeHeartbeatMessageSent = now;
				}

                // send available message if it has been atleast 10 milliseconds since the last
                // this ensures messages sent to safety board are not sent to close together
                // the safety board can't handle messages to close together
                if (queue.size() > 0 && std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeMessageSent).count() >= (1000 / ACTUAL_MSG_RATE_HZ))
                {
                    if (!queue.empty())
                    {
                        std::vector<char> data = queue.front();
                        queue.pop();

                        int num = serialPort.writeBuffer(data.data(), data.size());
                    }
                    lastTimeMessageSent = now;
                }

                // check if communications were lost based on timeout
                if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastTimeDataReceived).count() >= COMM_TIMEOUT_MS)
                {
                    isCommunicating = false;
                }
			}

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     GetMessages     /////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void SafetyBoard::GetMessages()
            {
                int dataRead = 0;
                while ((dataRead = serialPort.readBuffer(&buffer[currentIndex], BUFFER_SIZE - currentIndex)) > 0)
                {
                    currentIndex += dataRead;

                    int i = 0;
                    for (i = 0; i < currentIndex - 5; i++)
                    {
                        // is this the start of a message? hmmmmmm
                        if (buffer[i + 0] == SafetyBoard_Messages::SYNC1 &&
                            buffer[i + 1] == SafetyBoard_Messages::SYNC2 &&
                            buffer[i + 2] == SafetyBoard_Messages::SYNC3 &&
                            buffer[i + 3] == SafetyBoard_Messages::SYNC4)
                        {
                            SafetyBoard_Messages::Type messageType = (SafetyBoard_Messages::Type)(unsigned char)buffer[i + 4];

                            // circuit enable messages don't have an ID in the message so check first byte of circuit to determine if this message is a circuit enable response
                            SafetyBoard_Messages::CircuitEnable::CircuitEnum circuitEnum = *(SafetyBoard_Messages::CircuitEnable::CircuitEnum*)&buffer[i + 4];
                            if (circuitEnum == SafetyBoard_Messages::CircuitEnable::CircuitEnum::CIRCUIT1 ||
                                circuitEnum == SafetyBoard_Messages::CircuitEnable::CircuitEnum::CIRCUIT2 ||
                                circuitEnum == SafetyBoard_Messages::CircuitEnable::CircuitEnum::CIRCUIT3 ||
                                circuitEnum == SafetyBoard_Messages::CircuitEnable::CircuitEnum::CIRCUIT4)
                            {
                                messageType = SafetyBoard_Messages::Type::CIRCUIT_ENABLE;
                            }

                            // get the message size so we can determine if we have enough data in the buffer
                            int messageSize = 0;
                            switch (messageType)
                            {
                            case SafetyBoard_Messages::Type::HEARTBEAT_MESSAGE: messageSize = sizeof(SafetyBoard_Messages::HeartbeatResponse); break;
                            case SafetyBoard_Messages::Type::CIRCUIT_ENABLE:    messageSize = sizeof(SafetyBoard_Messages::CircuitEnable); break;
                            case SafetyBoard_Messages::Type::CIRCUIT_ERROR:     messageSize = sizeof(SafetyBoard_Messages::CircuitError); break;
                            default: i += 3; continue; // if it is a message ID that we don't handle then skip (i + 3 since for loop also increments)
                            }

                            // make sure we have enough data for the whole message
                            if (currentIndex - i < messageSize)
                                break;

                            // calculate checksum
                            unsigned int calculatedChecksum = 0;
                            for (int k = i; k < i + messageSize - 3; k++)
                                calculatedChecksum += (unsigned char)buffer[k];

                            bool wasGood = false;

                            // process the message
                            switch (messageType)
                            {
                            case SafetyBoard_Messages::Type::HEARTBEAT_MESSAGE: { SafetyBoard_Messages::HeartbeatResponse message;    memcpy(&message, &buffer[i], messageSize);  wasGood = ProcessHeartbeatResponse(message);                   break; }
                            case SafetyBoard_Messages::Type::CIRCUIT_ENABLE:    { SafetyBoard_Messages::CircuitEnable message;        memcpy(&message, &buffer[i], messageSize);  wasGood = ProcessCircuitEnable(message, calculatedChecksum);   break; }
                            case SafetyBoard_Messages::Type::CIRCUIT_ERROR:     { SafetyBoard_Messages::CircuitError message;         memcpy(&message, &buffer[i], messageSize);  wasGood = ProcessCircuitError(message);                        break; }
                            }

                            if (wasGood)
                            {
                                isCommunicating = true;
                                lastTimeDataReceived = std::chrono::steady_clock::now();
                                i += messageSize - 1; // minus 1 since the for loop also increments
                            }
                            else
                                i += 3;
                        }
                    }

                    //Any remaining data needs to be moved to the front of the line
                    int dataRemaining = currentIndex - i;
                    if (dataRemaining > 0 && i != 0)
                        memcpy(buffer, &buffer[i], dataRemaining);
                    currentIndex = dataRemaining;
                }
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     QueueHeartbeat     //////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void SafetyBoard::QueueHeartbeat()
            {
				// send message and increment count
                char* buffer = reinterpret_cast<char*>(&lastSentHeartbeatMessage);
                std::vector<char> v(buffer, buffer + sizeof(lastSentHeartbeatMessage));
                queue.push(v);
                //logFile->AddLine(logPrefix + "heartbeat sent");
                sentHeartbeatMessageCount++;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     QueueCircuitEnable     //////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            void SafetyBoard::QueueCircuitEnable(SafetyBoard_Messages::CircuitEnable::CircuitEnum circuit)
            {
                lastSentCircuitEnableMessage.setCircuit(circuit);

                unsigned short checksum = 0;
                const uint8_t* p = reinterpret_cast<const uint8_t*>(&lastSentCircuitEnableMessage);
                int messageSize = sizeof(lastSentCircuitEnableMessage);

                // loop and set the checksum for each byte of message. 
                for (int i = 0; i < messageSize - 3; i++)
                    checksum += p[i];

                // Set the check sums
                lastSentCircuitEnableMessage.cksum_lsb = static_cast<uint8_t>(checksum & 0x00FF);
                lastSentCircuitEnableMessage.cksum_msb = static_cast<uint8_t>((checksum >> 8) & 0x00FF);

                char* buffer = reinterpret_cast<char*>(&lastSentCircuitEnableMessage);
                std::vector<char> v(buffer, buffer + messageSize);
                queue.push(v);
                logFile->AddLine(logPrefix + "circuit enable for circuit: " + std::to_string((int)circuit) + " sent");
                sentCircuitEnableMessageCount++;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     ProcessHeartbeatResponse     ////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            bool SafetyBoard::ProcessHeartbeatResponse(SafetyBoard_Messages::HeartbeatResponse message)
            {
                lastReceivedHeartbeatResponseMessage = message;
                receivedHeartbeatResponseMessageCount++;
                //logFile->AddLine(logPrefix + "heartbeat response received with status: " + std::to_string((int)message.status));
                return true;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     ProcessCircuitEnable     ////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            bool SafetyBoard::ProcessCircuitEnable(SafetyBoard_Messages::CircuitEnable message, unsigned int checksum)
            {
                char calcMsb = (char)((checksum & 0xFF00) >> 8);
                char calcLsb = (char)(checksum & 0x00FF);

                // something was wrong with this message so don't process
                if (calcMsb != message.cksum_msb || calcLsb != message.cksum_lsb)
                    return false;

                lastReceivedCircuitEnableMessage = message;
                receivedCircuitEnableMessageCount++;
                logFile->AddLine(logPrefix + "circuit enable received");
                return true;
            }

            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     ProcessCircuitError     /////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
            bool SafetyBoard::ProcessCircuitError(SafetyBoard_Messages::CircuitError message)
            {
                receivedCircuitErrorMessageCount++;
                logFile->AddLine(logPrefix + "circuit error received");
                return true;
            }
		}
	}
}