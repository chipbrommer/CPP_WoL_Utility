#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Message structs for safety board object communications.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
//
///////////////////////////////////////////////////////////////////////////////

#pragma pack(push, 1)
namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
            class SafetyBoard_Messages
            {
            public:
                enum class Type
                {
                    HEARTBEAT_MESSAGE = 0x59,
                    CIRCUIT_ENABLE = 0x67,
                    CIRCUIT_ERROR = 0x86
                };

                static const char SYNC1 = 0xFA;         // byte used in message sync
                static const char SYNC2 = 0xF3;         // byte used in message sync
                static const char SYNC3 = 0x20;         // byte used in message sync
                static const char SYNC4 = 0x75;         // byte used in message sync
                static const char TAG_BIT_1 = 0x4F;    // tag byte using in message
                static const char TAG_BIT_2 = 0x55;    // tag byte using in message
                static const char TAG_BIT_3 = 0x18;    // tag byte using in message
                static const char EOM_BIT = 0xB7;      // eom byte used in message

                struct HEADER
                {
                public:
                    char sync1;                         // 0xFA
                    char sync2;                         // 0xF3
                    char sync3;                         // 0x20
                    char sync4;                         // 0x75

                private:
                    char id;

                public:
                    Type getType() { return (Type)id; }

                    void setType(Type value) { id = (char)value; }
                };

                struct HeartbeatMessage                // from CPU to safety card
                {
                public:
                    HEADER header;
                    char tag1;                          // 0x4F
                    char tag2;                          // 0x55
                    char tag3;                          // 0x18
                    char eom;                           // 0xB7
                };

                struct HeartbeatResponse               // from safety card to CPU
                {
                public:
                    enum class StatusEnum
                    {
                        ENABLED = 1,
                        LOCKED = 2
                    };

                    HEADER header;
                    char status;                        // 0x01 = enabled, 0x02=lock out
                    char tag1;                          // 0x4F
                    char tag2;                          // 0x55
                    char tag3;                          // 0x18
                    char eom;                           // 0xB7

                    StatusEnum getStatus() { return (StatusEnum)status; }
                };

                struct CircuitEnable                   // CPU sends to enable, safety card responsed with same when enabled
                {
                public:
                    enum class CircuitEnum
                    {
                        CIRCUIT1 = 0x11111111,
                        CIRCUIT2 = 0x22222222,
                        CIRCUIT3 = 0x33333333,
                        CIRCUIT4 = 0x44444444
                    };

                    char sync1;                         // 0xFA
                    char sync2;                         // 0xF3
                    char sync3;                         // 0x20
                    char sync4;                         // 0x75

                private:
                    unsigned int circuit;               // 0x11111111 (enable 1), 0x22222222 (enable 2)
                                                        // 0x33333333 (enable 3), 0x44444444 (enable 4)
                                                        // any other value disables all circuits

                public:
                    char tag1;                          // 0x4F
                    char tag2;                          // 0x55
                    char tag3;                          // 0x18
                    char cksum_lsb;                     // least significant public char of unsigned 16-bit sum of preceeding public chars
                    char cksum_msb;                     // most significant public char of unsigned 16-bit sum of preceeding public chars
                    char eom;                           // 0xB7

                public:
                    CircuitEnum getCircuit() { return (CircuitEnum)circuit; }

                    void setCircuit(CircuitEnum value) { circuit = (unsigned int)value; }
                };

                struct CircuitError                    // safety board sends to CPU when unable to enable a circuit
                {
                public:
                    HEADER header;
                    char eom;                           // 0xB7
                };
            };
		}
	}
}
#pragma pack(pop)