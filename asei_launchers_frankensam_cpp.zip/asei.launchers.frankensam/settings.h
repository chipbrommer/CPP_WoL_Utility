#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Structure to hold setting data.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
#define RAPIDJSON_HAS_STDSTRING 1
#include	"rapidjson/document.h"			 // rapid json functionality
#include	"rapidjson/stringbuffer.h"		 // rapid json functionality
#include	"rapidjson/writer.h"			 // rapid json functionality
#include	"rapidjson/prettywriter.h"		 // rapid json functionality
//           								  
#include	"asei.essentials/settingsfile.h" // settings file object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam 
		{
			class SettingsData : public asei::essentials::Data 
			{
			public:
				std::string ioBoardComPort = "COM1";
				std::string safetyBoardComPort = "COM2";
				std::string powerBoardComPort = "COM3";

				std::string broadcastIP = "127.0.0.255";
				unsigned short broadcastPort = 8213;
				unsigned short listenPort = 8214;

				//! @brief implementation of required virtual function to serialize all data into a string
				//! @return - the resulting string of serialized data
				std::string SerializeData()
				{
					rapidjson::Document document;
					document.SetObject();
					document.AddMember("ioBoardComPort", ioBoardComPort, document.GetAllocator());
					document.AddMember("safetyBoardComPort", safetyBoardComPort, document.GetAllocator());
					document.AddMember("powerBoardComPort", powerBoardComPort, document.GetAllocator());
					document.AddMember("broadcastIP", broadcastIP, document.GetAllocator());
					document.AddMember("broadcastPort", broadcastPort, document.GetAllocator());

					rapidjson::StringBuffer strBuf;
					strBuf.Clear();

					rapidjson::PrettyWriter<rapidjson::StringBuffer> writer(strBuf);
					document.Accept(writer);

					return std::string(strBuf.GetString());
				}

				//! @brief implementation of required virtual function to deserialize string back into data values
				//! @param data - the string to be deserialize
				void DeserializeData(std::string data)
				{
					rapidjson::Document document;
					document.Parse(data.c_str());

					if (document.HasMember("ioBoardComPort")) ioBoardComPort = document["ioBoardComPort"].GetString();
					if (document.HasMember("safetyBoardComPort")) safetyBoardComPort = document["safetyBoardComPort"].GetString();
					if (document.HasMember("powerBoardComPort")) powerBoardComPort = document["powerBoardComPort"].GetString();
					if (document.HasMember("broadcastIP")) broadcastIP = document["broadcastIP"].GetString();
					if (document.HasMember("broadcastPort")) broadcastPort = (unsigned short)document["broadcastPort"].GetInt();
				}
			};
		}
	}
}