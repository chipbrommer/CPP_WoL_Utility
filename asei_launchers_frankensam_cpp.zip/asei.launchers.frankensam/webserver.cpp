
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations for web server object components.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
#include	"webserver.h"					 // web server header
//               
#include	"nlohmann/json.hpp"				 // json objects
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			WebServer* WebServer::instance = nullptr;	// a gross singleton link instance for the program's web server instance. used by the mongoose c like functions

			// used by mongoose to signal things
			static int s_signo;
			static void signal_handler(int signo) 
			{
				s_signo = signo;
			}

			enum WebSocketType
			{
				UNKNOWN,
				MAIN,
				TELEMETRY,
				SAFETYBOARD_TM
			};

			//! @brief function being called by mongoose timer for the life of the program.
			//!		   updates each web socket connection with the latest data
			//! @param param - the mongoose manager reference
			void updateWebSockets(void* param)
			{
				struct mg_connection* c;

				mg_mgr* mgr = (struct mg_mgr*)param;
				for (c = mgr->conns; c != NULL; c = c->next) 
				{
					std::string data = "";
					switch ((WebSocketType)c->data[0])
					{
					case WebSocketType::MAIN:		data = WebServer::instance->GetMainData().dump();		break;
					case WebSocketType::TELEMETRY:	data = WebServer::instance->GetTelemetryData().dump();	break;
					}
				
					if (data != "")
						mg_ws_send(c, data.c_str(), data.length(), WEBSOCKET_OP_TEXT);
				}
			}

			//! @brief the callback triggered for every web server event
			//! @param c - the connection maintained by mongoose for this event
			//! @param ev - the event type
			//! @param ev_data - the message data for this event
			//! @param fn_data - the web server object reference
			void cb(struct mg_connection* c, int ev, void* ev_data, void* fn_data) 
			{
				WebServer* webServer = (WebServer*)fn_data;

				struct mg_http_message* hm = (struct mg_http_message*)ev_data, tmp = { 0 };

				if (ev == MG_EV_OPEN && c->is_listening)
				{
					mg_timer_add(c->mgr, 100, MG_TIMER_REPEAT, updateWebSockets, c->mgr);
				}
				if (ev == MG_EV_HTTP_MSG)
				{
					if (mg_http_match_uri(hm, "/") || mg_http_match_uri(hm, "/index") || mg_http_match_uri(hm, "/index.html"))
					{
						std::string bodyContent = webServer->env.render_file("index.html", webServer->GetMainData());
						std::string wholePage = webServer->env.render_file("layout.html", { { "title", "Home" }, { "bodyContent", bodyContent } });
						mg_http_reply(c, 200, "Content-Type: text/html; charset=utf-8\r\n", wholePage.c_str());
					}
					else if (mg_http_match_uri(hm, "/telemetry") || mg_http_match_uri(hm, "/telemetry.html"))
					{
						std::string bodyContent = webServer->env.render_file("telemetry.html", webServer->GetTelemetryData());
						std::string wholePage = webServer->env.render_file("layout.html", { { "title", "Telemetry" }, { "bodyContent", bodyContent } });
						mg_http_reply(c, 200, "Content-Type: text/html; charset=utf-8\r\n", wholePage.c_str());
					}
					else if (mg_http_match_uri(hm, "/settings") || mg_http_match_uri(hm, "/settings.html"))
					{
						char buffer[1024];
						int numReceived = 0;

						nlohmann::json json;
						json["isSaveSuccessful"] = false;

						try
						{
							// check for post data
							numReceived = mg_http_get_var(&hm->body, "ioboardComPort", buffer, 1024);
							if (numReceived > 0)
							{
								webServer->launcher->settingsFile.data.ioBoardComPort = std::string(buffer);

								numReceived = mg_http_get_var(&hm->body, "safetyboardComPort", buffer, 1024);
								if (numReceived > 0) webServer->launcher->settingsFile.data.safetyBoardComPort = std::string(buffer);

								numReceived = mg_http_get_var(&hm->body, "powerboardComPort", buffer, 1024);
								if (numReceived > 0) webServer->launcher->settingsFile.data.powerBoardComPort = std::string(buffer);

								numReceived = mg_http_get_var(&hm->body, "broadcastIp", buffer, 1024);
								if (numReceived > 0) webServer->launcher->settingsFile.data.broadcastIP = std::string(buffer);

								numReceived = mg_http_get_var(&hm->body, "broadcastPort", buffer, 1024);
								if (numReceived > 0) webServer->launcher->settingsFile.data.broadcastPort = std::stoi(buffer);

								if (!webServer->launcher->settingsFile.Save())
									webServer->launcher->settingsFile.Load();
								else
									json["isSaveSuccessful"] = true;
							}
						}
						catch (std::exception e) { }

						json["ioboardComPort"] = webServer->launcher->settingsFile.data.ioBoardComPort;
						json["safetyboardComPort"] = webServer->launcher->settingsFile.data.safetyBoardComPort;
						json["powerboardComPort"] = webServer->launcher->settingsFile.data.powerBoardComPort;
						json["broadcastIp"] = webServer->launcher->settingsFile.data.broadcastIP;
						json["broadcastPort"] = webServer->launcher->settingsFile.data.broadcastPort;

						std::string bodyContent = webServer->env.render_file("settings.html", json);
						std::string wholePage = webServer->env.render_file("layout.html", { { "title", "Settings" }, { "bodyContent", bodyContent } });
						mg_http_reply(c, 200, "Content-Type: text/html; charset=utf-8\r\n", wholePage.c_str());
					}
					else if (mg_http_match_uri(hm, "/ws-main"))
					{
						c->data[0] = (char)WebSocketType::MAIN;
						mg_ws_upgrade(c, hm, NULL);
					}
					else if (mg_http_match_uri(hm, "/ws-telemetry"))
					{
						c->data[0] = (char)WebSocketType::TELEMETRY;
						mg_ws_upgrade(c, hm, NULL);
					}
					else
					{
						struct mg_http_serve_opts opts = { 0 };
						opts.root_dir = webServer->rootDir.c_str();
						mg_http_serve_dir(c, hm, &opts);
					}
				}
				else if (ev == MG_EV_WS_MSG)
				{
					struct mg_ws_message* msg = (struct mg_ws_message*)ev_data;
				}
				(void)fn_data;
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     WebServer     ///////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			WebServer::WebServer(std::string rootDir, int port, Launcher* launcher) :
				env{ rootDir.c_str() }
			{
				this->launcher = launcher;
				this->rootDir = rootDir;
				this->listening_address = "http://0.0.0.0:" + std::to_string(port);

				instance = this;

				// Initialise stuff
				signal(SIGINT, signal_handler);
				signal(SIGTERM, signal_handler);
				mg_mgr_init(&mgr);
				if ((c = mg_http_listen(&mgr, listening_address.c_str(), cb, this)) == NULL) 
				{
					MG_ERROR(("Cannot listen on %s. Use http://ADDR:PORT or :PORT", listening_address));
					exit(EXIT_FAILURE);
				}
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     Start     ///////////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			void WebServer::Start()
			{
				// Start infinite event loop
				MG_INFO(("Mongoose version : v%s", MG_VERSION));
				MG_INFO(("Listening on     : %s", listening_address.c_str()));
				MG_INFO(("Web root         : [%s]", rootDir.c_str()));
				while (s_signo == 0) mg_mgr_poll(&mgr, 20);
				mg_mgr_free(&mgr);
				MG_INFO(("Exiting on signal %d", s_signo));
			}
			
            /////////////////////////////////////////////////////////////////////////////////////////////
            ///////////     GetMainData     /////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////////////
			nlohmann::json WebServer::GetMainData()
			{
				nlohmann::json json = {
					{ "isMissionComputerCommunicating", launcher->missionComputer.isCommunicating },
					{ "isIoBoardCommunicating", launcher->ioBoard.isCommunicating },
					{ "isSafetyBoardCommunicating", launcher->safetyBoard.isCommunicating },
					{ "isPowerBoardCommunicating", launcher->powerBoard.isCommunicating },
					{ "isConsentEnabled", launcher->isConsentSwitchEnabled },
					{ "isArmEnabled", launcher->isArmSwitchEnabled },
					{ "isFireEnabled", launcher->isFireSwitchEnabled },
					{ "power", {
						{ "dcVoltage", launcher->powerBoard.statusMessage.inputPower.dcVoltage },
						{ "dcCurrent", launcher->powerBoard.statusMessage.inputPower.dcCurrent },
						{ "acVoltagePhase1", launcher->powerBoard.statusMessage.inputPower.acVoltagePhase1 },
						{ "acCurrentPhase1", launcher->powerBoard.statusMessage.inputPower.acCurrentPhase1 },
						{ "acVoltagePhase2", launcher->powerBoard.statusMessage.inputPower.acVoltagePhase2 },
						{ "acCurrentPhase2", launcher->powerBoard.statusMessage.inputPower.acCurrentPhase2 },
						{ "acVoltagePhase3", launcher->powerBoard.statusMessage.inputPower.acVoltagePhase3 },
						{ "acCurrentPhase3", launcher->powerBoard.statusMessage.inputPower.acCurrentPhase3 }
					}}
				};

				json["missiles"] = nlohmann::json::array();
				for (int i = 0; i < launcher->NUM_MISSILES; i++)
				{
					json["missiles"].push_back(nlohmann::json::object());
					json["missiles"][i] = {
						{ "isPresent", launcher->missiles[i].isPresent },
						{ "isPowered", launcher->missiles[i].isPowerEnabled },
						{ "power", {
							{ "dcVoltage", launcher->powerBoard.statusMessage.lauPower[i].dcVoltage },
							{ "dcCurrent", launcher->powerBoard.statusMessage.lauPower[i].dcCurrent },
							{ "acVoltagePhase1", launcher->powerBoard.statusMessage.lauPower[i].acVoltagePhase1 },
							{ "acCurrentPhase1", launcher->powerBoard.statusMessage.lauPower[i].acCurrentPhase1 },
							{ "acVoltagePhase2", launcher->powerBoard.statusMessage.lauPower[i].acVoltagePhase2 },
							{ "acCurrentPhase2", launcher->powerBoard.statusMessage.lauPower[i].acCurrentPhase2 },
							{ "acVoltagePhase3", launcher->powerBoard.statusMessage.lauPower[i].acVoltagePhase3 },
							{ "acCurrentPhase3", launcher->powerBoard.statusMessage.lauPower[i].acCurrentPhase3 }
						}}
					};
				}
				//std::string bleh = json.dump();
				return json;
			}

			/////////////////////////////////////////////////////////////////////////////////////////////
			///////////     GetTelemetryData     ////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////
			nlohmann::json WebServer::GetTelemetryData()
			{
				nlohmann::json json = {
					{ "ioboard", {
						{ "inputMessageCount",		launcher->ioBoard.inputMessageCount },
						{ "outputMessageCount",		launcher->ioBoard.outputMessageCount },
						{ "version",				launcher->ioBoard.inputMessage.version }
					}},
					{ "safetyboard", {
						{ "sentHeartbeatMessageCount", launcher->safetyBoard.sentHeartbeatMessageCount },
						{ "sentCircuitEnableMessageCount", launcher->safetyBoard.sentCircuitEnableMessageCount },
						{ "receivedHeartbeatResponseMessageCount", launcher->safetyBoard.receivedHeartbeatResponseMessageCount },
						{ "receivedCircuitEnableMessageCount", launcher->safetyBoard.receivedCircuitEnableMessageCount },
						{ "receivedCircuitErrorMessageCount", launcher->safetyBoard.receivedCircuitErrorMessageCount }
					}}
				};
				return json;
			}
		}
	}
}