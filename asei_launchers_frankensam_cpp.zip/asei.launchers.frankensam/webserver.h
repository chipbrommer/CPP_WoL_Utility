#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing the web server.  Handles receiving
//					web request and sending responses.
//
//  Include files:
//          name								reason included
//          --------------------				---------------------  
//               
#include	<string>						 // string type
//               
#include	"inja/inja.hpp"					 // templating functionality
#include	"mongoose.h"					 // web interface logic
//               
#include	"launcher.h"					 // launcher object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace launchers
	{
		namespace frankensam
		{
			class WebServer
			{
			private:
				std::string listening_address;	// the address/port that is used to listen for incoming web request

				struct mg_mgr mgr;				// the mongoose manager
				struct mg_connection* c;		// the mongoose connection pointer used by mongoose callbacks

			public:
				Launcher* launcher;				// a reference to the launcher object to get data for pages and websockets
				static WebServer* instance;		// a gross singleton like reference to the program's web server instance (needed for global c functions)

				std::string rootDir;			// the root directory that will be accessed for web files
				inja::Environment env;			// the inja environment used to generate resulting html with data populated

				//! @brief constructor that sets up and initializes the web server
				WebServer(std::string rootDir, int port, Launcher* launcher);

				//! @brief starts the web server process (this blocks the calling thread)
				void Start();

				//! @brief generates the json object containing all the data needed for the main webpage
				nlohmann::json GetMainData();

				//! @brief generates the json object containing all the data needed for the telemetry page
				nlohmann::json GetTelemetryData();
			};
		}
	}
}