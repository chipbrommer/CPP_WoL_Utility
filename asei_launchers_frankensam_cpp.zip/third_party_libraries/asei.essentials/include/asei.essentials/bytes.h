#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Collection of file system utility functions.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace essentials
	{
		class Bytes
		{
		public:
			//! @brief checks if a specified bit is set in the input
			//! @param input - the value to read the specified bit from
			//! @param bitIndex - the index of the bit to read
			//! @return true/false if the specified bit was set
			static bool GetBit(char input, int bitIndex);

			//! @brief sets a specified bit to a specified value in the input
			//! @param input - the input to set the specified bit in
			//! @param bitIndex - the index of the bit to set
			//! @param value - the value to the bit to
			//! @return the resulting input with the set specified bit
			static char SetBit(char input, int bitIndex, bool value);
		};
	}
}