#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing a log file. Uses a separate thread to
//                  handle disk IO.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<string>						 // string object
#include	<mutex>							 // mutex object for thread safety
#include	<queue>							 // queue object
#include	<thread>						 // thread object
#include	<fstream>						 // file streams
#include	<vector>						 // vector object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace essentials
	{
		class LogFile
		{
		private:
			bool isRunning = true;					// used by the separate thread to know if it should continue running
			std::thread running_thread;				// the separate thread used to handle disk IO

			std::string file_path;					// the path to the log file being written
			std::ofstream file_stream;				// the open stream to the log file to write data to

			std::queue<std::vector<char>> queue;	// a queue to store data waiting to be written by separate thread
			std::mutex queue_locker;				// a mutex to ensure thread safety of the queue

			bool shouldwritelinestoconsole;			// boolean to know if new lines should be written to the console

		public:
			//! @brief creates log file and start separate thread for disk IO
			//! @param file_path - the path of the file to create
			//! @param shouldwritelinestoconsole - enables log entries to 
			//!           to also be written to the console window
			LogFile(std::string file_path, bool shouldwritelinestoconsole);

			//! @brief cleans up the log file and cleanly ends the separate thread
			~LogFile();

			//! @brief adds one line of text to the log file
			//! @param line1 - the line to add to the text file
			//! @param addnewlinecharacter - determines if a newline character
			//!           should be added to the line being added to the log file
			void AddLine(std::string line1, bool addnewlinecharacter = true);

			//! @brief adds a block of binary data to the log file
			//! @param data - the binary data to add to the log file
			//! @param size - the size of the binary data
			void AddData(const char* data, int size);
		};
	}
}