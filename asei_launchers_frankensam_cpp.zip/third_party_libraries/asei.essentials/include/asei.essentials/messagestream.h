#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing a message stream with messages using a
//                     byte to declare the start / end of a new message with
//                     a byte used to escape special bytes in the message.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<vector>						 // vector object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace essentials
	{
		class MessageStream
		{
		private:
			unsigned char messageByte;					// the byte representing the start / end of a message
			unsigned char escapeByte;					// the byte used to escape other escape bytes and the message byte

			static const int BUFFER_SIZE = 1500;		// the size of the buffer to store incoming data
			unsigned char buffer[BUFFER_SIZE] = { 0 };	// the buffer to store data that will be parsed for messages

			bool isInMessage = false;					// boolean indicating if the current position in the buffer is in a message
			bool isEscape = false;						// boolean indicating if the current position in the buffer is escaped
			int messageLength = 0;						// length used to maintain the total message length of the current message being parse

		public:
			//! @brief initializes the message stream object
			//! @param messageByte - the byte representing the start / end of a message
			//! @param escapeByte - the byte used to escape other escape bytes and the message byte
			void Initialize(unsigned char messageByte, unsigned char escapeByte);

			//! @brief parses a collection of messages from the partial last data received and the new data
			//! @param data - the new data to try to parse messages from
			//! @param length - length of the new data
			//! @return a collection of byte arrays representing each message received
			std::vector<std::vector<unsigned char>> GetMessages(unsigned char* data, int length);

			//! @brief takes in message and packs it with the message and escape bytes
			//! @param data - the data to pack
			//! @param length - the length of the data to pack
			//! @param dest - the resulting packed message
			//! @return the length of the resulting packed message
			int PackMessage(void* data, int length, unsigned char* dest);
		};
	}
}