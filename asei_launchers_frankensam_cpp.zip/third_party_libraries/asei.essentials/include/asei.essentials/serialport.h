#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Implementations of the functions for the serial port object.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<string>						 // string object
//
#if defined(__linux__) 
#include	<fcntl.h>						 // Linux file controls
#include	<errno.h>						 // Linux error handling
#include	<termios.h>						 // Linux terminal control
#include	<unistd.h>						 // Linux read, write, close
#elif defined(_WIN32)
#include	<WinSock2.h>					 // Windows sockets
#include	<Windows.h>						 // Windows Serial Support
#endif
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace essentials
	{
		class SerialPort
		{
		public:
			//! @brief Overloaded connect method to set baud rate.
			//! @param port - Serial port for connection
			//! @param rate - Specific baudrate for the serial connection
			//! @return -1 on error, 0 on success
			bool connect(std::string port, int rate);

			//! @brief Closes a serial connection 
			//! @return -1 on error, 0 on success
			int closeSerial();

			//! @brief Flushes a serial stream
			//! @return -1 on error, 0 on success
			int flushSerial();

			//! @brief Reads a buffer from stream of set size 
			//! @param buffer - Char buffer to store data read from serail into
			//! @param maxSize - size of buffer or size of data to read. 
			//! @return -1 on error, 0 on no data sent, else number of bytes read
			int readBuffer(char* buffer, int maxSize);

			//! @brief  Writes a buffer over over stream of set size
			//! @param buffer - Data to send over serial
			//! @param size - size of buffer to send over serial
			//! @return -1 on error, 0 on no data sent, else number of bytes sent
			int writeBuffer(const void* buffer, int size);

			//! @brief Bool if the connection is open. 
			//! @return True if connection is open, else false
			bool isOpen();

		private:
			// Variables
			HANDLE m_status = 0;					//!< Holds "Handle" for Serial conenction. 
			bool opened = false;
		};
	}
}