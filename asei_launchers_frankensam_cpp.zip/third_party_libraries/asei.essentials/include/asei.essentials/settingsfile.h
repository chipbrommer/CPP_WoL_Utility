#pragma once

#include <fstream>
#include <sstream>
#include <string>
#include <type_traits>

#include "utilities_filesystem.h"

namespace asei
{
	namespace essentials
	{
		class Data
		{
		public:
			virtual std::string SerializeData() = 0;
			virtual void DeserializeData(std::string data) = 0;
		};

		template <typename T = Data>
		class SettingsFile
		{
			std::string file_path;

		public:
			T data;

			SettingsFile(std::string file_path)
			{
				this->file_path = file_path;
			}

			bool Load() 
			{
				try
				{
					struct stat buffer;
					if (stat(file_path.c_str(), &buffer) == 0)
					{
						std::ifstream file(file_path.c_str());
						std::stringstream buffer;
						buffer << file.rdbuf();

						std::string json = buffer.str();
						data.DeserializeData(json);
					}
				}
				catch (std::exception) { }

				return Save();
			}

			bool Save()
			{
				try
				{
					// create directory in case it doesn't exist
					std::string directory = Utilities::FileSystem::GetDirectoryFromFilePath(file_path);
					Utilities::FileSystem::CreateDirectoryFromPath(directory);

					std::fstream file(file_path.c_str(), std::fstream::out);

					std::string json = data.SerializeData();
					file << json;

					file.close();

					return true;
				}
				catch (std::exception) { }

				return false;
			}
		};
	}
}