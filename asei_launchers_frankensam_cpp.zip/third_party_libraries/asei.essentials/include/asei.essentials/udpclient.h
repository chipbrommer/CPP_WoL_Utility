#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Object representing a udp client.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#define _WINSOCK_DEPRECATED_NO_WARNINGS		 // Ignore depreciations on windows winsock2.h
#pragma comment(lib, "Ws2_32.lib")			 // Include the winsock2 ibrary
#include	<winsock2.h>				     // Windows socket support
#include	<ws2tcpip.h>					 // Windows IP protocol support
#include	<string>						 // Strings
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace essentials
	{
		class UdpClient
		{
		public:
			struct IPEndPoint
			{
				std::string ip;			// the ip of the endpoint
				unsigned short port;	// the port of the endpoint
			};

		private:
			int32_t m_socket = 0;		// the socket handler
			sockaddr_in m_address{};	// the listening address

		public:
			//! @brief initializes the udp client
			//! @param listenPort - the port the udp client will listen on
			UdpClient(unsigned short listenPort);

			//! @brief send data to the specified endpoint
			//! @param data - the data to send
			//! @param size - the size of the data to send
			//! @param endPoint - the endpoint to send the data to
			//! @return the number of byte sent
			int Send(void* data, int size, IPEndPoint endPoint);

			//! @brief receives data from the udp client and populates the endpoint with senders info
			//! @param data - the location for the data received
			//! @param length - the max length of data to try and receive
			//! @param endPoint - the endpoint info for the sender
			//! @return - the number of bytes received
			int Recv(void* data, int length, IPEndPoint* endPoint);
		};
	}
}