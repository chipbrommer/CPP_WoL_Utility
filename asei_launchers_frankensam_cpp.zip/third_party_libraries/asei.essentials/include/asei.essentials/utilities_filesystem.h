#pragma once
///////////////////////////////////////////////////////////////////////////////
//
//  Applied Systems Engineering Inc. proprietary rights are included in the
//  information disclosed herein.
//
//  Recipient by accepting this document or software agrees that neither
//  this software nor the information disclosed herein nor any part thereof
//  shall be reproduced or transferred to other documents or software or used
//  or disclosed to others for any purpose except as specifically authorized
//  in writing by:
//
//                     Applied Systems Engineering Inc
//                            Niceville, Florida
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//
//	Description:	Collection of file system utility functions.
//
//  Include files:
//          name								reason included
//          --------------------				-------------------------------
//
#include	<string>						 // string object
//
///////////////////////////////////////////////////////////////////////////////

namespace asei
{
	namespace essentials
	{
		class Utilities
		{
		public:
			class FileSystem
			{
			public:
				//! @brief tries to create a directory for the specified directory path
				//! @param path - the path to create the directory for
				static void CreateDirectoryFromPath(std::string location);

				//! @brief extracts the directory from a specified file path
				//! @param file_path - the path of the file to extract the directory from
				//! @return the resulting directory if it could extract it, else an empty string
				static std::string GetDirectoryFromFilePath(std::string file_path);
			};
		};
	}
}